<?php
define('SITE_NAME','Food Ordering Admin');
define('FRONT_SITE_NAME','Food Ordering');

define('FRONT_SITE_PATH','http://127.0.0.1/php/food_ordering/');
define('SERVER_IMAGE',$_SERVER['DOCUMENT_ROOT']."/php/food_ordering/");

define('SERVER_DISH_IMAGE',SERVER_IMAGE."media/dish/");
define('SITE_DISH_IMAGE',FRONT_SITE_PATH."media/dish/");

define('SERVER_BANNER_IMAGE',SERVER_IMAGE."media/banner/");
define('SITE_BANNER_IMAGE',FRONT_SITE_PATH."media/banner/");

?>