<?php
include ("header.php");
?>

<div class="breadcrumb-area gray-bg">
            <div class="container">
                <div class="breadcrumb-content">
                    <ul>
                        <li><a href="<?php echo FRONT_SITE_PATH?>shop">Home</a></li>
                        <li class="active">About us </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="about-us-area pt-50 pb-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-7 d-flex align-items-center">
                        <div class="overview-content-2">
                            <h2>Welcome To <span>Food Ordering</span> Store !</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse risus est, pulvinar imperdiet risus non, tristique imperdiet justo. Donec tempus consequat orci et posuere. Nullam tempus, eros ut scelerisque aliquam, justo nisi scelerisque tellus, eget pharetra justo neque a dolor. Vivamus feugiat blandit tellus nec elementum. Aliquam eu purus tellus. Cras ut massa ut erat maximus porta non et nunc. Nam gravida venenatis felis, in ullamcorper enim vehicula et. Etiam quis lectus eleifend, accumsan risus sed, fringilla risus. Nunc ullamcorper laoreet est, in rhoncus dolor varius ut. Vivamus ut varius turpis. Praesent ornare eu orci sit amet congue. Morbi varius sed nulla a semper.</p>
                            <p>In dictum turpis sit amet sem ornare iaculis. Nunc posuere dui ac magna fringilla pharetra. Phasellus interdum pulvinar facilisis. Donec auctor rutrum malesuada. Curabitur consequat nisl lectus, vel hendrerit nisl feugiat nec. Curabitur nec iaculis odio. Donec scelerisque pretium nisi, iaculis volutpat ante hendrerit vitae. Sed pretium vitae arcu nec tempor. Quisque a enim blandit, tempus arcu eu, auctor nulla.

</p>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>

<?php
include("footer.php");
?>